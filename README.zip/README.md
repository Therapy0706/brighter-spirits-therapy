# Brighter Spirits, PLLC React App
This is a basic React project to help deploy your therapy site.