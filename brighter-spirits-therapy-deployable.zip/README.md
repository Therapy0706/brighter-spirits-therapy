# Brighter Spirits, PLLC
This is a React-based website for Brighter Spirits, ready to deploy on Vercel.