import React from 'react';

function App() {
  return (
    <div>
      <h1>Welcome to Brighter Spirits, PLLC</h1>
      <p>Your path to healing starts here.</p>
    </div>
  );
}

export default App;
