import React from 'react';

function App() {
  return (
    <div>
      <h1>Brighter Spirits, PLLC</h1>
      <p>Welcome to trauma-informed care for your healing journey.</p>
    </div>
  );
}

export default App;
