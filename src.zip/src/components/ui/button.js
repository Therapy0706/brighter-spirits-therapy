// Button component placeholder
export const Button = ({ children, variant, ...props }) => <button {...props} className={`btn-${variant}`}>{children}</button>;