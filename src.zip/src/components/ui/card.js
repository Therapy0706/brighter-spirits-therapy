// Card component placeholder
export const Card = ({ children }) => <div>{children}</div>;
export const CardContent = ({ children, className }) => <div className={className}>{children}</div>;