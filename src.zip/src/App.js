import React from 'react';

function App() {
  return (
    <div>
      <h1>Welcome to Brighter Spirits, PLLC</h1>
      <p>This is your React app.</p>
    </div>
  );
}

export default App;
