import React from "react";
import BrighterSpiritsHome from "./BrighterSpiritsHome";

function App() {
  return <BrighterSpiritsHome />;
}

export default App;