import React from "react";

export default function BrighterSpiritsHome() {
  return (
    <main style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <div style={{ textAlign: "center", marginBottom: "2rem" }}>
        <img
          src="https://cdn.dribbble.com/users/1162077/screenshots/3848914/therapy-session-telehealth.gif"
          alt="Telehealth session"
          style={{ width: "100%", maxWidth: "600px", borderRadius: "10px", boxShadow: "0 4px 8px rgba(0,0,0,0.1)" }}
        />
        <h1 style={{ fontSize: "2rem", marginTop: "1rem" }}>Brighter Spirits, PLLC</h1>
        <p style={{ maxWidth: "600px", margin: "1rem auto" }}>
          Trauma-informed psychotherapy for clients ages 10 and up, rooted in spiritual integration,
          cultural humility, and evidence-based care.
        </p>
      </div>
    </main>
  );
}